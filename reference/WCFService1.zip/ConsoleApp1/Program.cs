﻿using ConsoleApp1.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var a = new ServiceReference1.Service1Client();
                var b = a.GetDataUsingDataContract(new CompositeType
                {
                    BoolValue = true,
                    StringValue = "AAA"
                });
                var c = 0;
            }
            catch(Exception ex)
            {
                Console.WriteLine("ERROR");
                Console.WriteLine(ex);
            }
        }
    }
}
